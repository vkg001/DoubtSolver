import React from 'react'

const UserDetail = () => {
  return (
    <div>
       <h1>user details</h1>
    </div>
  )
}

export default UserDetail
