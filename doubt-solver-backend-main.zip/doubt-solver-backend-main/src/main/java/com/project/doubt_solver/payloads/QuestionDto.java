package com.project.doubt_solver.payloads;

public class QuestionDto {

    private String email;
    private String Question;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }
}
