package com.project.doubt_solver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoubtSolverApplicationTests {

	@Test
	void contextLoads() {
	}

}
